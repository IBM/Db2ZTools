package com.ibm.db2zos.devops;

class DOEProcess {
  private Properties props = ['doehost': '', 'doeport': '', 'username': '',
         'appAPI': '/ws/policy/applications/', 'teamAPI': '/ws/policy/teams/',
         'subsysAPI': '/ws/policy/subsystems/', 'instAPI': '/ws/policy/instances/',
         'pullAPI': '/ws/policy/pull-requests/', 'appClass': 'com.rocketsoft.newton.policy.Application',
         'teamClass': 'com.rocketsoft.newton.policy.Team', 'subsysClass': 'com.rocketsoft.newton.policy.Subsystem',
         'instClass': 'com.rocketsoft.newton.policy.Instance', 'pullClass': 'com.rocketsoft.newton.policy.PullRequest'];
  private String respEncoding = "";
  private String surl = "";
  private String credential = "";
  Map apifields = [appAPI:'applications', teamAPI:'teams', 
                          subsysAPI:'subsystems', instAPI:'instances', 
                          pullAPI:'pull-requests'];
  Map uuidfields = [appAPI:'appID', teamAPI:'teamID',
                          subsysAPI:'subsysID', instAPI:'instID',
                          pullAPI:'pullID'];
  Map uuidvals = [:];
  Map teamEnvList = [:];
  def schemaNames = [];
  def schemaMap = [];
  def dbNames = [];
  def dbMap = [];
  def doList = [];
  def existingDOList = [];
  def appArray = [];

  class Instance {
    String __yamlClass
    String team
    String environment
    String application
    String name
  }

  class PullRequest {
    String __yamlClass
    String sourceRepository
    String sourceBranch
    String targetRepository
    String targetBranch
    List   reviewers
    String sourceInstanceId
  }

  class Db2Object {
    String __yamlClass
    String name
    String qualifier
    String subsystem
    String type
    String objectName
    String [] requiredObjects
  }

  class NewObj {
    String __yamlClass
    String ddl
    String objectName
    Db2Object db2object
  }

  DOEProcess(String doehost, String doeport, String username, String password) {
    props.doehost = doehost;
    props.doeport = doeport;
    props.username = username;
    respEncoding = System.getProperty("file.encoding");
    surl = "http://" + props.doehost + ":" + props.doeport;
    credential = "$username:$password".
                     getBytes("ISO-8859-1").encodeBase64().toString();
  }

  def mfAnalysis(String appMFName) {
    def data = new groovy.json.JsonSlurper().parse(new BufferedReader(
                               new InputStreamReader(new FileInputStream(appMFName))))
    if (!appArray.contains(data.application)) {
        appArray += data.application;
        if (data.dependency != null && data.dependency.size() > 0)
            data.dependency.each { mfAnalysis(it.application_uri) };
        if (data.manifest_uri != null && data.manifest_uri != '')
            doList += new groovy.json.JsonSlurper().parse(new BufferedReader(new InputStreamReader(
              new FileInputStream(data.manifest_uri)))).objects;
    }
//    println(appArray);
//    println(doList);
  }

/*******************************************
** The method is for implemented for different scenarios, which reads property file to initilize the object props.
********************************************  
  void getProps(String propFileName) {
   props = new Properties();
	File propFile = new File(propFileName)
	propFile.withInputStream {
		props.load(it)
	}
  }
*/

  //Generic UUID parser
  void getUUID(String objType, String objName) { 
    def getURL = new URL(surl + props."$objType").openConnection();
    getURL.setRequestProperty("Authorization", "Basic $credential");
    def getRC = getURL.responseCode;
    println(getRC);
    def field = "";
    String respText;
    String origText;
    if(getRC.equals(200)) {
       def slurper = new groovy.json.JsonSlurper();
       origText = getURL.inputStream.text;
       respText = origText;
       def result;
       try {
         result = slurper.parseText(respText);
       }
       //processing when the default JVM encoding is IBM-1047. Some DOE APIs returned different encoding than others even at different round,
       //hence, it is cleaner to use try-catch mechanism to handle this than to check different conditions (which polutes the code)
       catch(JsonException){  
       //  println("need to convert encoding");
         String respTextN = new String(origText.getBytes("Cp1047"),"UTF-8");
         result = slurper.parseText(respTextN);
       }
       def apif = apifields."$objType";
       int apino = result."$apif".size();
       int i = 0;
       int foundID = 0;
       while (i < apino) {
          if (result."$apif"[i].name == objName) {
             def uuidf = uuidfields."$objType";
             uuidvals["$uuidf"] = result."$apif"[i].id;
             //println("$uuidf"+ " "+uuidvals."$uuidf");
             foundID = 1;
             //special processing to get the environment list for the team
             if (objType == "teamAPI") {
                def envNList = new ArrayList();
                def envIDList = new ArrayList();
                int j = 0;
                int envListCount = result."$apif"[i].environments.size();
                //println(result."$apif"[i].environments);
                //println(envListCount);
                while (j < envListCount) {
                   teamEnvList.put(result."$apif"[i].environments[j].name, result."$apif"[i].environments[j].id);
                   j++;
                }
                //println(teamEnvList);
             }
          }
          i++;
       }
       if (foundID == 0) { //the id is null for the case that object doesn't exist
          println("no match found: "+ objType + "." + objName);
       }
    }  //else the id is null for the requested object
  }

   void getObjectList() {
      // invoke instanceID GET call, instead of instanceID/objects GET call, to avoid another call to get subsystem ID
      def getURL = surl + props.instAPI + uuidvals.instID;
      def getReq = new URL(getURL).openConnection();
      getReq.setRequestProperty("Authorization", "Basic $credential");
      def getRC = getReq.responseCode; 
      println(getRC);
      String origText;
      String respText;     
      if (getRC.equals(200)) {
         def slurper = new groovy.json.JsonSlurper();
         origText = getReq.inputStream.text;
         respText = origText;
         def result;
         try {
          result = slurper.parseText(respText);
         }
         //processing when the default JVM encoding is IBM-1047. Some DOE APIs returned different encoding than others even at different round,
         //hence, it is cleaner to use try-catch mechanism to handle this than to check different conditions (which polutes the code)
         catch(JsonException){  
         //  println("need to convert encoding");
          String respTextN = new String(origText.getBytes("Cp1047"),"UTF-8");
          result = slurper.parseText(respTextN);
         }
         int i = 0;
         int objCount = result.db2objects.size();
         uuidvals.subsysID = result.db2objects[i].subsystem;
         dbMap = result.databaseMap;
         // get application ID as well for future usage
         uuidvals.appID = result.application;
         while (i < objCount) {
            String fullName = "";
            if (result.db2objects[i].qualifier == "")
               fullName = result.db2objects[i].name;
            else {
               // get the schema name list as well for future usage
               if (!(schemaNames.contains(result.db2objects[i].qualifier)))
                  schemaNames << result.db2objects[i].qualifier;
               fullName = result.db2objects[i].qualifier + '.' + result.db2objects[i].name;
            }
            existingDOList << fullName;
            i++;
        }
      }
   }

   String addObject(String objID, String objType, String qName, String objURI) {
      def ddlLines = [];
      new File( objURI ).eachLine('UTF-8') { line ->
         ddlLines << line;
      }
      def ddlStr = ddlLines.join('\n');
      Db2Object pdObj = new Db2Object(__yamlClass: "com.rocketsoft.newton.policy.Db2Object", 
                              name: objID, qualifier: qName, subsystem: uuidvals.subsysID, type: objType, objectName: "policy.db2object", 
                              requiredObjects: []);
      NewObj pObj = new NewObj(__yamlClass: "com.rocketsoft.newton.policy.NewInstanceDb2Object", ddl: ddlStr, objectName: "policy.newInstanceObject", 
                               db2object: pdObj);
      def pReqJ = new groovy.json.JsonBuilder(pObj);
      print(pReqJ);

      def pURL = surl + props.instAPI + uuidvals.instID + "/objects";
      def pReq = new URL(pURL).openConnection();
      pReq.setRequestMethod("POST");
      pReq.setRequestProperty("Authorization", "Basic $credential");
      pReq.setRequestProperty("Content-Type", "application/json");
      pReq.setDoInput(true);
      pReq.setDoOutput(true);
      String outStr;
      if (respEncoding == "IBM-1047")
         outStr = new String(pReqJ.toString().getBytes("UTF-8"), "Cp1047");
      else
         outStr = pReqJ.toString();      
         pReq.outputStream.withWriter { Writer writer ->
         writer << outStr; 
      }

      def pRC = pReq.responseCode;
      println("return code of adding object is " + pRC);
      if(pRC.equals(200)) {
         println("object added for " + objID);
      }
      return pRC;
   }

   String saveChange(String objID, String objURI) {
      def pURL = surl + props.instAPI + uuidvals.instID + "/objects/" + 
                 objID + "?save=true";
      def pReq = new URL(pURL).openConnection();
      pReq.setRequestMethod("PUT");
      pReq.setRequestProperty("Authorization", "Basic $credential");
      pReq.setDoInput(true);
      pReq.setDoOutput(true);
      def objFile = new File(objURI);
      pReq.outputStream.withWriter { Writer writer ->
         writer << objFile.text; 
      }

      def putRC = pReq.responseCode;
      println("return code of saving change is " + putRC);
      if(putRC.equals(200)) {
         println("changes saved for " + objID);
      }
      return putRC;
   }

   def requestAction(String apiType, String subAction, String expected, def method=null) {
     def apiID = uuidfields."$apiType";
     def postURL = "";
     postURL = surl + props."$apiType" + uuidvals."$apiID" + "/" + subAction; 
     def postReq = new URL(postURL).openConnection();
     if (method != null)
        postReq.setRequestMethod(method);
     else
        postReq.setRequestMethod("POST");
     postReq.setRequestProperty("Authorization", "Basic $credential");
     postReq.setDoInput(true);
     postReq.setDoOutput(true);
     def postRC = postReq.responseCode;
     println(postRC);
     String origText;
     String respText;
     if(postRC.equals(200) && method == null) {
       def slurper = new groovy.json.JsonSlurper();
       origText = postReq.inputStream.text;
       respText = origText;
       def result;
       try {
         result = slurper.parseText(respText);
       }
       //processing when the default JVM encoding is IBM-1047. Some DOE APIs returned different encoding than others even at different round,
       //hence, it is cleaner to use try-catch mechanism to handle this than to check different conditions (which polutes the code)
       catch(JsonException){  
       //  println("need to convert encoding");
         String respTextN = new String(origText.getBytes("Cp1047"),"UTF-8");
         result = slurper.parseText(respTextN);
       }
       return result."$expected";
     }
     return postRC;
   }

   Map getReport(String apiType, String subAction, String jobid) {
     Map reportMap = [status:"waiting",report:""];
     def apiID = uuidfields."$apiType";
     def getURL = surl+props."$apiType"+uuidvals."$apiID"+"/"+subAction+"/"+jobid+"?verbose=true";
     def getReq = new URL(getURL).openConnection();
     getReq.setRequestProperty("Authorization", "Basic $credential");
     getReq.setFollowRedirects(false);
     def getRC = getReq.responseCode; 
     println(getRC);
     String origText;
     String respText;     
     if (getRC.equals(200)) {
       def slurper = new groovy.json.JsonSlurper();
       origText = getReq.inputStream.text;
       respText = origText;
       def result;
       try {
         result = slurper.parseText(respText);
       }
       //processing when the default JVM encoding is IBM-1047. Some DOE APIs returned different encoding than others even at different round,
       //hence, it is cleaner to use try-catch mechanism to handle this than to check different conditions (which polutes the code)
       catch(JsonException){  
       //  println("need to convert encoding");
         String respTextN = new String(origText.getBytes("Cp1047"),"UTF-8");
         result = slurper.parseText(respTextN);
       }

       def isDone = result.isComplete;
       if (isDone) {
          reportMap.report = result.verboseReport.join('"').replace('"',System.lineSeparator());
          reportMap.status = "done";
       }
       else
          reportMap.status = "waiting";
     }
     else {
       reportMap.status = "failed";
       reportMap.report = "Failed for reason code: " + getRC;
     }
     return(reportMap);
   }

   String checkStatus(String apiType, String expectedStatus = null) {
     def objID = uuidfields."$apiType";
     def getURL = surl+props."$apiType" + uuidvals."$objID";
     def getReq = new URL(getURL).openConnection();
     getReq.setRequestProperty("Authorization", "Basic $credential");
     getReq.setRequestProperty("Content-Type", "application/json; charset=utf-8");
     def getRC = getReq.responseCode;
     println(getRC);
     String respText;
     String origText;
     if (getRC.equals(200)) {
       def slurper = new groovy.json.JsonSlurper();
       origText = getReq.inputStream.text;
       respText = origText;
       def result;
       try {
         result = slurper.parseText(respText);
       }
       //processing when the default JVM encoding is IBM-1047(like running on USS). Some DOE APIs returned different encoding than others even at different round,
       //hence, it is cleaner to use try-catch mechanism to handle this than to check different conditions (which polutes the code)
       catch(JsonException){
       //  println("need to convert encoding");
         String respTextN = new String(origText.getBytes("Cp1047"),"UTF-8");
         result = slurper.parseText(respTextN);
       }
       if (result.status== "complete" && apiType == "instAPI") {
            schemaNames = result.schemaNames;
            dbNames = result.databaseNames;

            int i = 0;
            int objCount = result.db2objects.size();
            uuidvals.subsysID = result.db2objects[i].subsystem;
            dbMap = result.databaseMap;
            schemaMap = result.schemaMap;
            // get application ID as well for future usage
            uuidvals.appID = result.application;
            while (i < objCount) {
               String fullName = "";
               if (result.db2objects[i].qualifier == "")
                  fullName = result.db2objects[i].name;
               else {
                  // get the schema name list as well for future usage
                  if (!(schemaNames.contains(result.db2objects[i].qualifier)))
                     schemaNames << result.db2objects[i].qualifier;
                  fullName = result.db2objects[i].qualifier + '.' + result.db2objects[i].name;
               } 
               existingDOList << fullName;
               i++;
            }
       }
       return (result.status);
     }
     else if (getRC.equals(404) && expectedStatus == null)
       return ("completed");
     else
       return ("failed with reason code: " + getRC);
   }

   String provision(String appName, String teamName, String envName, String instName) {
      getUUID("appAPI", appName);
      //println("done with appAPI");
      getUUID("teamAPI", teamName);
      //println("done with teamAPI");
      String envID = teamEnvList.get(envName);
      String tID = uuidvals.teamID;
      String aID = uuidvals.appID;
      //println(tID);
      //println(aID);
      //println(envID);
      Instance pInst = new Instance(__yamlClass:props.instClass, team:tID, 
                                   environment:envID, application:aID, 
                                   name:instName);
      def pInstJ = new groovy.json.JsonBuilder(pInst);
      print(pInstJ);
      def postURL = surl + props.instAPI;
      def postReq = new URL(postURL).openConnection();
      postReq.setRequestMethod("POST");
      postReq.setRequestProperty("Authorization", "Basic $credential");
      postReq.setDoInput(true);
      postReq.setDoOutput(true);
      postReq.setRequestProperty("Content-Type", "application/json");
      String outStr;
      if (respEncoding == "IBM-1047")
         outStr = new String(pInstJ.toString().getBytes("UTF-8"), "Cp1047");
      else
         outStr = pInstJ.toString();      
      postReq.outputStream.withWriter { Writer writer ->
        writer << outStr; 
      }

      def postRC = postReq.responseCode;
      println(postRC);
      String respText;
      String origText;
      if (postRC.equals(201)) {
        def slurper = new groovy.json.JsonSlurper();
        origText = postReq.inputStream.text;
        respText = origText;
        def result;
        try {
          result = slurper.parseText(respText);
        }
        //processing when the default JVM encoding is IBM-1047(like running on USS). Some DOE APIs returned different encoding than others even at different round,
        //hence, it is cleaner to use try-catch mechanism to handle this than to check different conditions (which polutes the code)
        catch(JsonException){
        //  println("need to convert encoding");
          String respTextN = new String(origText.getBytes("Cp1047"),"UTF-8");
          result = slurper.parseText(respTextN);
        }

        def resultS = result.status;
        uuidvals.instID = result.id;
        if (resultS != "instantiating")
           return ("failed to provision with status: " + resultS);           
        while (resultS == "instantiating") {
           sleep(5000);
           resultS = checkStatus("instAPI", "complete");
        }
        println("the schema name of the newly provisioned instance is " + schemaNames);
        return resultS; 
      }
      else
        return ("failed to provision with reason code: " + postRC);
   }

   String deprovision(String name) {
      getUUID("instAPI", name)
      requestAction("instAPI", "", "", "DELETE");
      def result = checkStatus("instAPI");
      while (result == "deleting") {
          sleep(5000);
          result = checkStatus("instAPI");
      }
      return (result);
   }

   Map reviewChange(String instName, String appMFName) {
      getUUID("instAPI", instName);
      checkStatus("instAPI", "complete");
      mfAnalysis(appMFName);
      def i = 0;
      def dbSet = dbMap.keySet();
      def qk;
      def qv;
      while (i < doList.size()) {
         qk = doList[i].qualifier;
         if (!(['DB','TS'].contains(doList[i].type))) {
            qv = schemaMap["$qk"];
            if (existingDOList.contains(qv + "." + doList[i].name)) {
               saveChange(qv + "." + doList[i].name, doList[i].uri);
            }
            else
               addObject(doList[i].name, doList[i].type, doList[i].qualifier, doList[i].uri);
         }
         else if (doList[i].type == 'TS') {
            qv = dbMap["$qk"];
            if (existingDOList.contains(qv + "." + doList[i].name)) {
               saveChange(qv + "." + doList[i].name, doList[i].uri);
            }
            else
               addObject(doList[i].name, doList[i].type, doList[i].qualifier, doList[i].uri);
         }
         else 
            if (dbSet.contains(doList[i].name))
               saveChange(dbNames[0], doList[i].uri);
            else
               addObject(doList[i].name, doList[i].type, '', doList[i].uri)               
         i++;
      }
      def jobid = requestAction("instAPI", "report", "jobid");
      def result = getReport("instAPI", "report", jobid);
      println(result);
      while (result.status == "waiting") {
          sleep(2000);
          result = getReport("instAPI", "report", jobid);
          println(result.status);
      }
      println(result.report);
      return (result);
   }

   Map applyChange(String instName) {
      getUUID("instAPI", instName);
      def jobid = requestAction("instAPI", "apply", "jobid");
      def result = getReport("instAPI", "apply", jobid);
      while (result.status == "waiting") {
          sleep(2000);
          result = getReport("instAPI", "apply", jobid);
      }
      println(result.report);
      return (result);
   }
 
   String promoteChange(String instName) {
      getUUID("instAPI", instName);
      List ruser = [];
      ruser.add(props.username);
      PullRequest pullReq = new PullRequest(__yamlClass:props.pullClass, sourceRepository:"instances",
                                   sourceBranch:uuidvals.instID, targetRepository:"applications",
                                   targetBranch:"master", reviewers:ruser,
                                   sourceInstanceId:uuidvals.instID);
      def pReqJ = new groovy.json.JsonBuilder(pullReq);
      def postURL = surl + props.pullAPI;
      def postReq = new URL(postURL).openConnection();
      postReq.setRequestMethod("POST");
      postReq.setRequestProperty("Authorization", "Basic $credential");
      postReq.setDoInput(true);
      postReq.setDoOutput(true);
      postReq.setRequestProperty("Content-Type", "application/json");
      String outStr;
      if (respEncoding == "IBM-1047")
         outStr = new String(pReqJ.toString().getBytes("UTF-8"), "Cp1047");
      else
         outStr = pReqJ.toString();
      postReq.outputStream.withWriter { Writer writer ->
         writer << outStr;
      }

      def postRC = postReq.responseCode;
      println(postRC);
      String origText;
      String respText;
      if (postRC.equals(201)) {
         def slurper = new groovy.json.JsonSlurper();
        origText = postReq.inputStream.text;
        respText = origText;
        def result;
        try {
          result = slurper.parseText(respText);
        }
        //processing when the default JVM encoding is IBM-1047(like running on USS). Some DOE APIs returned different encoding than others even at different round,
        //hence, it is cleaner to use try-catch mechanism to handle this than to check different conditions (which polutes the code)
        catch(JsonException){
        //  println("need to convert encoding");
          String respTextN = new String(origText.getBytes("Cp1047"),"UTF-8");
          result = slurper.parseText(respTextN);
        }

         uuidvals.pullID = result.id;
         def aStatus = requestAction("pullAPI", "approve", "status");
         def pStatus;
         println("approval status: " + aStatus);
         if (aStatus.toUpperCase() == "OPENED") {
            aStatus = requestAction("pullAPI", "merge", "status");
            println("merge status: " + aStatus)
            pStatus = checkStatus("pullAPI");
            while (pStatus == "merging") {
               sleep(5000);
               pStatus = checkStatus("pullAPI");
               println(pStatus);
            }
            println(pStatus);
            if (pStatus.toUpperCase() != "MERGED")
               return("failed to merge the change automatically, require manual merge");
            return (pStatus);
         }
         else
            return("failed to get approval, contact administrator to check");
      }
      else
         return ("failed to create pull request");
   }

   Map syncChange(String instName) {
      getUUID("instAPI", instName);
      println(requestAction("instAPI", "objects/pull", "db2objects"));
      return (applyChange(instName));
   }
}
