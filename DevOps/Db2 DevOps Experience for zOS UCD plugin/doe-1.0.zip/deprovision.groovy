/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Build
 * IBM UrbanCode Deploy
 * IBM UrbanCode Release
 * IBM AnthillPro
 * IBM Db2 for z/OS
 * (c) Copyright IBM Corporation 2002, 2019. All Rights Reserved.

 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.AirPluginTool
import com.ibm.db2zos.devops.DOEProcess


try{
	def apTool = new AirPluginTool(this.args[0], this.args[1])
	final def workDir = new File('.').canonicalFile
	def props = apTool.getStepProperties();

	final def instanceName = props['instanceName']?.trim();
	final def doehost = props['doeServer']?.trim();
	final def doeport = props['doeServerPort']?.trim();	
	final def printRESTLOG = Boolean.valueOf(props['printRESTLOG']?.trim()); //checkbox

	//hidden
//	final def untrustedSSL = Boolean.valueOf(props['untrustedSSL']?.trim()); //checkbox
	final def userid = props['userid']?.trim();
	final def password = props['password']?.trim();
	
	//validate required input
	if(instanceName == null || instanceName.length()==0){
		throw new Exception("Instance Name must be set.");
	}

	if(doehost == null || doehost.length()==0){
		throw new Exception("DOE Server must be set.");
	}

	if(doeport == null || doeport.length()==0){
		throw new Exception("DOE Server Port must be set.");
	}

	if(userid == null || userid.length()==0){
		throw new Exception("User Name must be set.");
	}

	if(password == null || password.trim().length()==0){
		throw new Exception("Password must be set.");
	}

	def doepObj = new DOEProcess(doehost, doeport, userid, password);
	def dpresult = doepObj.deprovision(instanceName);

	apTool.setOutputProperty("doe.deprovisionStatus", dpresult);	
	apTool.storeOutputProperties();
	if (dpresult.indexOf("failed") != -1)
		System.exit(1);
}catch (Exception e) {
	println "Error starting workflow : ${e.message}";
	e.printStackTrace();
	System.exit(1);
}