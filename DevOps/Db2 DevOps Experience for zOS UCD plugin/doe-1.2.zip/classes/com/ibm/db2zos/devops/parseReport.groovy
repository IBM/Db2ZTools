import groovy.json.JsonSlurper

def loop(array) {
    array.each { entry ->
        if(entry["Children"].size() == 0)
            println(entry["Source Object"] + ": " + entry["Result"])
        else
            loop(entry["Children"])
    }
}

def loop2(array) {
    for(entry in array) {
        if(entry["Children"].size() == 0)
            println(entry["Source Object"] + ": " + entry["Result"])
        else
            loop2(entry["Children"])
    }
}

def file = new File("C:/Users/BenedictHolste/Documents/Nazare/ucd-doe-plugin/classes/com/ibm/db2zos/devops/report.json");
def jsonString = file.getText("UTF-8");
//println(jsonString)#
def parsedJson = new JsonSlurper().parseText(jsonString)
//println(parsedJson)
//loop2(parsedJson["summaryReportJson"]["Results"])
//println(new groovy.json.JsonBuilder(parsedJson).toString())
println(parsedJson)