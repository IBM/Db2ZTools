package com.ibm.db2zos.devops

import javax.net.ssl.*
import javax.security.cert.*
import groovy.json.JsonSlurper

/**
* Implements the different actions against IBM Db2 DevOps Experience for z/OS
**/
class DOEProcess {
  private Properties props = ['doehost': '', 'doeport': '', 'username': '',
         'appAPI': '/ws/policy/applications/', 'teamAPI': '/ws/policy/teams/',
         'subsysAPI': '/ws/policy/subsystems/db2/', 'instAPI': '/ws/policy/instances/',
         'pullAPI': '/ws/policy/pull-requests/', 'envAPI':'/ws/policy/environments/',
         'rulesAPI': '/ws/site-rules/', 
         'appClass': 'com.rocketsoft.newton.policy.Application',
         'teamClass': 'com.rocketsoft.newton.policy.Team', 'subsysClass': 'com.rocketsoft.newton.policy.Subsystem',
         'instClass': 'com.rocketsoft.newton.policy.Instance', 'pullClass': 'com.rocketsoft.newton.policy.PullRequest'];
  private String respEncoding = "";
  private String baseUrl = "";
  private String credential = "";
  Map apifields = [appAPI:'applications', teamAPI:'teams', 
                          subsysAPI:'subsystems', instAPI:'instances', 
                          pullAPI:'pull-requests'];
  Map uuidfields = [appAPI:'appID', teamAPI:'teamID',
                          subsysAPI:'subsysID', instAPI:'instID',
                          pullAPI:'pullID'];
  Map uuidvals = [:];
  Map teamEnvList = [:];
  //schemaNames contains db name for tablespaces besides schema name, and is used for comparison of objects in save and add actions
  public def schemaNames = [];
  //schemaList contains the schema name only
  public def schemaList = [];
  def schemaMap = [];
  public def dbNames = [];
  def dbMap = [:];
  def doList = [];
  def existingDOList = [];
  def appArray = [];
  public def jdbcurl = "";
  public def db2version = "";
  public def db2functionlevel = "";

  // untrusted SSL
  def untrustedSSL;

  def printRESTlog = false;

  def debug = false;

  def logLevel = 0

  class Instance {
    String __yamlClass
    String teamId
    String environmentId
    String[] applicationIds
    String name
  }

  class PullRequest {
    String __yamlClass
    String sourceRepository
    String sourceBranch
    String targetRepository
    String targetBranch
    List reviewers
    String sourceInstanceId
    String title
  }

  class Db2Object {
    String __yamlClass
    String name
    String qualifier
    String subsystem
    String type
    String objectName
    String [] requiredObjects
  }

  class NewObj {
    String __yamlClass
    String ddl
    String objectName
    Db2Object db2object
  }

  void logINFO(String msg) {
     println("INFO: ${msg}")
  }

  void logDEBUG(String msg) {
     if(logLevel >= 4)
      println("DEBUG: ${msg}")
  }

  DOEProcess(String doehost, String doeport, String username, String password, boolean untrustedSSL, boolean printRESTlog) {
    props.doehost = doehost;
    props.doeport = doeport;
    props.username = username;
    respEncoding = System.getProperty("file.encoding");
    baseUrl = "https://" + props.doehost + ":" + props.doeport;
    credential = "$username:$password".
                     getBytes("ISO-8859-1").encodeBase64().toString();
   this.untrustedSSL = untrustedSSL;
   this.printRESTlog = printRESTlog

   // Install the all-trusting trust manager
   if (untrustedSSL) {
      try {
         SSLContext sc = SSLContext.getInstance("TLS");
         sc.init(null, [new DefaultTrustManager()] as TrustManager[], new java.security.SecureRandom());
         HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
      } catch (Exception e) {
         println(e)
      }
   }
  }

   /**
    * Do a HTTP request to the specified URL
    *
    * @param urlString
    * @param method
    * @param body
    *
    * @return A Map of responseCode and responseContent
    */
   Map doRequest(String urlString, String method="GET", String body=null) {

      HttpsURLConnection conn = (HttpsURLConnection) new URL(urlString).openConnection();
      if (untrustedSSL) {
         conn.setHostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String arg0, SSLSession arg1) {
                return true;
            }
        });
      }

      conn.setRequestMethod(method)
      //conn.setFollowRedirects(false);

      // Set HTTP headers
      conn.setRequestProperty("Authorization", "Basic $credential")
      conn.setRequestProperty("Accept", "application/json")

      // Write data to outputStream
      if(method != "GET") {
         conn.setDoOutput(true)
         conn.setRequestProperty("Content-Type", "application/json")
         if(body != null) {
            def outString = body
            // Convert the request body to IBM-1047
            if(respEncoding == "IBM-1047")
               outString = new String(body.getBytes("UTF-8"), "Cp1047")
            conn.outputStream.withWriter { Writer writer -> writer << outString } 
         }
      }

      // Send the request
      def responseCode = conn.responseCode
      def responseContent

      // Read the response
      if(responseCode < 400)
         responseContent = conn.inputStream.getText("UTF-8")
      else
         responseContent = conn.errorStream.getText("UTF-8")

      // Print the REST call
      if(printRESTlog) {
         println("${conn.getRequestMethod()} ${conn.getURL()} returned ${responseCode} ${conn.getResponseMessage()}")
         if(body != null)
            println("Request body: ${body}")
         println("Response content: ${responseContent}")
      }

      return ["responseCode":responseCode, "responseContent":responseContent]
   }

/**
* Creates a HttpsURLConnection to the specified URL
**/
   HttpsURLConnection openConnection(String urlString) {

      HttpsURLConnection conn = (HttpsURLConnection) new URL(urlString).openConnection();
      if (untrustedSSL) {
         conn.setHostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String arg0, SSLSession arg1) {
                return true;
            }
        });
      }

      // Add HTTP Basic Authentication header
      conn.setRequestProperty("Authorization", "Basic $credential");

      println(conn.getURL())

      // return the HttpsConnectionURL object
      return conn;
   }

   /**
   * Parse a JSON String
   * 
   * @param jsonString The JSON as String to be parsed
   * @return The parsed JSON object
   */
   def parseJson(String jsonString) {
      def parsedJson
      def jsonSlurper = new JsonSlurper()
      try {
         parsedJson = jsonSlurper.parseText(jsonString);
      }
      //processing when the default JVM encoding is IBM-1047. Some DOE APIs returned different encoding than others even at different round,
      //hence, it is cleaner to use try-catch mechanism to handle this than to check different conditions (which polutes the code)
      catch(JsonException){  
      //  println("need to convert encoding");
         String convertedJsonString = new String(jsonString.getBytes("Cp1047"),"UTF-8");
         parsedJson = jsonSlurper.parseText(convertedJsonString);
      }
      return parsedJson
   }
    
   /**
    * Read and analyze the application manifest JSON file
    * 
    * @param appMFName The name of the application manifest file
    */
  def mfAnalysis(String appMFName) {
     logDEBUG("Entering mfAnalysis with parms appMFName=${appMFName}")
    def data = new groovy.json.JsonSlurper().parse(new BufferedReader(
                               new InputStreamReader(new FileInputStream(appMFName))));
    if (!appArray.contains(data.application)) {
        appArray += data.application;
        if (data.dependency != null && data.dependency.size() > 0)
            data.dependency.each { mfAnalysis(it.application_uri) };
        if (data.manifest_uri != null && data.manifest_uri != '')
            doList += new groovy.json.JsonSlurper().parse(new BufferedReader(new InputStreamReader(
              new FileInputStream(data.manifest_uri)))).objects;
    }
//    println(appArray);
//    println(doList);
   logDEBUG("Exiting mfAnalysis")
  }

/* The method is for implemented for different scenarios, which reads property file to initilize the object props.
   void getProps(String propFileName) {
      props = new Properties();
      File propFile = new File(propFileName)
      propFile.withInputStream {
      props.load(it)
      }
   } */

  /**
   * Get the UUID for a specific object
   *
   * @param objType The type of the object (instAPI, appAPI, teamAPI, pullAPI, subsysAPI, envAPI)
   * @param objName The name of the obejct
  */
  void getUUID(String objType, String objName) { 
     logDEBUG("Entering getUUID with parms objType=${objType}, objName=${objName}")
    def getUrl = baseUrl + props."$objType"
    if(objType == "instAPI")
      getUrl = getUrl.take(getUrl.size()-1) + "?excludeStatus=deleted&fields=name"
    def getReq = doRequest(getUrl);
    def getRC = getReq.responseCode;
    def field = "";

   def result = parseJson(getReq.responseContent)

    if(getRC.equals(200)) {
       def apif = apifields."$objType";
       int apino = result."$apif".size();
       //println("getUUID returned " + result."$apif")
       int i = 0;
       int foundID = 0;
       while (i < apino) {
          if (result."$apif"[i].name == objName) {
             def uuidf = uuidfields."$objType";
             //println("## uuidf=${uuidf}")
             uuidvals["$uuidf"] = result."$apif"[i].id;
             //println("## uuidvals=${uuidvals}")
             //println("$uuidf"+ " "+uuidvals."$uuidf");
             foundID = 1;
             //special processing to get the environment list for the team
             if (objType == "teamAPI") {
                def envNList = new ArrayList();
                def envIDList = new ArrayList();
                int j = 0;
                int envListCount = result."$apif"[i].environments.size();
                //println(result."$apif"[i].environments);
                //println(envListCount);
                while (j < envListCount) {

                   def envId = result."$apif"[i].environments[j].environmentId

                   // get environment name
                   def req = doRequest(baseUrl + props.envAPI + envId)
                   def envName = parseJson(req.responseContent).name;

                   //println("## ${envId} ${envName}")
                   //teamEnvList.put(result."$apif"[i].environments[j].name, result."$apif"[i].environments[j].environmentId);
                   teamEnvList.put(envName, envId)
                   j++;
                }
                //println(teamEnvList);
             }
          }
          i++;
       }
       if (foundID == 0) { //the id is null for the case that object doesn't exist
          //println("no match found: "+ objType + "." + objName);
       }
    }  //else the id is null for the requested object
    else
    println("UUID lookup failed with error '${result.error}'");
   logDEBUG("Exiting getUUID")
  }

   /**
    * Get the list of objects for an instance
    * GET /ws/policy/instances/<instID>
    */
   void getObjectList() {
      // invoke instanceID GET call, instead of instanceID/objects GET call, to avoid another call to get subsystem ID
      def getURL = baseUrl + props.instAPI + uuidvals.instID;
      def getReq = doRequest(getURL);
      def getRC = getReq.responseCode; 
      
      def result = parseJson(getReq.responseContent)

      if (getRC.equals(200)) {
         int i = 0;
         int objCount = result.db2Objects.size();
         uuidvals.subsysID = result.db2Objects[i].subsystem;
         dbMap = result.db2.databaseMap;
         // get application ID as well for future usage
         uuidvals.appID = result.application;
         while (i < objCount) {
            String fullName = "";
            if (result.db2Objects[i].qualifier == "")
               fullName = result.db2Objects[i].name;
            else {
               // get the schema name list as well for future usage
               if (!(schemaNames.contains(result.db2Objects[i].qualifier)))
                  schemaNames << result.db2Objects[i].qualifier;
               fullName = result.db2Objects[i].qualifier + '.' + result.db2Objects[i].name;
            }
            existingDOList << fullName;
            i++;
        }
      }
      else
          println(result);
   }

   /**
    * Add new object to an instance
    * POST /ws/policy/instances/<instID>/objects
    *
    * @param objID The 
    * @param objType The type of the object (e.g. DB, TS, TB, IX)
    * @param qName
    * @param objURI
    */
   def addObject(String objID, String objType, String qName, String objURI) {
      logDEBUG("Entering addObject with parms objID=${objID}, objType=${objType}, qName=${qName}, objURI=${objURI}")
      def ddlLines = [];
      new File( objURI ).eachLine('UTF-8') { line ->
         ddlLines << line;
      }
      def ddlStr = ddlLines.join('\n');
      Db2Object pdObj = new Db2Object(__yamlClass: "com.rocketsoft.newton.policy.Db2Object", 
                              name: objID, qualifier: qName, subsystem: uuidvals.subsysID, type: objType, objectName: "policy.db2object", 
                              requiredObjects: []);
      NewObj pObj = new NewObj(__yamlClass: "com.rocketsoft.newton.policy.NewInstanceDb2Object", ddl: ddlStr, objectName: "policy.newInstanceObject", 
                               db2object: pdObj);
      def pReqJ = new groovy.json.JsonBuilder(pObj);
      //print(pReqJ);

      def pURL = baseUrl + props.instAPI + uuidvals.instID + "/objects";
      def pReq = doRequest(pURL, "POST", pReqJ.toString());

      def pRC = pReq.responseCode;
      println("return code of adding object is " + pRC);
      if(pRC.equals(200)) {
         println("Object ${objID} successfully added");
      }
      else {
         println("Error adding object ${objID}");
      }
      if(debug)
         println("Exiting addObject")
      return pRC;
   }

   /**
    * Save change of an object
    * PUT /ws/policy/instance/<instID>/objects/def
    *
    * @param objID
    * @param objURI
    */
   def saveChange(String objID, String objURI) {
      def pURL = baseUrl + props.instAPI + uuidvals.instID + "/objects/def?objectName=" + objID;
      def objFile = new File(objURI);
      def pReq = doRequest(pURL, "PUT", objFile.getText("UTF-8"));

      def putRC = pReq.responseCode;

      if(putRC.equals(200)) {
         println("Changes saved for object ${objID}");
      }
      else {
         println("Saving changes for object ${objID} failed with return code ${putRC}")
      }
      return putRC;
   }

   /**
   * Validate DDL against existing site rules
   * POST /site-rules/validate/db2
   *
   **/
   Map validateDDL(String ddl, String applicationId) {
      def url = baseUrl + props.rulesAPI + "validate/db2"
      def body = [ddl:ddl, application:applicationId]
      def postReq = doRequest(url, "POST", new groovy.json.JsonBuilder(body).toString())

      def postRC = postReq.responseCode;
      def result = parseJson(postReq.responseContent);

      def siterules = []

      // check for syntax errors
      if(result["syntaxErrors"]) {

         def syntaxMessages = []

         for (err in result["syntaxErrors"]) {
            def syntaxMsg = "Syntax error at line " + err["startLine"] +
               ", position " + err["startChar"] + 
               ", offending text: " + err["offendingText"]
            syntaxMessages.add(syntaxMsg)
         }
         return [returnCode: -1, messages: syntaxMessages]
      }
      // check site rules
      else {
         for (srv in result["siteRuleViolations"]) {
            def siterulemsg = "Site rule " + srv["rule"]["name"] + " violated for attribute " + srv["involvedAttributeTextChunks"][0]["text"]
            if ( srv["rule"]["ruleSpecification"] ) {
               siterulemsg = siterulemsg + srv["rule"]["ruleSpecification"]
            }
            else {
               siterulemsg = siterulemsg + ", verification attribute: " + srv["rule"]["attribute"] + ", verification type: " + srv["rule"]["verificationType"]
            }
            siterules.add(siterulemsg)
         }
      }
      def report = [returnCode: 0, messages: []]
      if(siterules.size() > 0) {
          report = [returnCode: -1, messages: siterules]
      }
      return report
   }

   /**
    * Request an action on a specific API
    *
    * @param apiType The API to be called
    * @param subAction The action to be executed
    * @param expected The expected status
    * @param method The HTTP method
    */
   def requestAction(String apiType, String subAction, String expected, def method=null) {
      logDEBUG("Entering requestAction with parms apiType=${apiType}, subAction=${subAction}, expected=${expected}, method=${method}")
      def apiID = uuidfields."$apiType";
      def postURL = "";
      postURL = baseUrl + props."$apiType" + uuidvals."$apiID" + "/" + subAction; 
     postURL = baseUrl + props."$apiType" + uuidvals."$apiID" + "/" + subAction; 
      postURL = baseUrl + props."$apiType" + uuidvals."$apiID" + "/" + subAction; 
      def postReq
      if (method != null)
         postReq = doRequest(postURL, method);
      else
         postReq = doRequest(postURL, "POST");
      
      def postRC = postReq.responseCode;
      def result = parseJson(postReq.responseContent);

      if(postRC.equals(200) && method == null) 
     if(postRC.equals(200) && method == null) 
      if(postRC.equals(200) && method == null) 
         return result."$expected";
      else
         println(result);

      return postRC;
   }

   /**
    * Get a report from a specific API
    *
    * @param apiType The API to be called
    * @param subAction The action to be executed
    * @param jobid 
    *
    * @return A Map containing the status and report
    */
   Map getReport(String apiType, String subAction, String jobid, Boolean includeSummaryReport=false) {
     Map reportMap = [status:"waiting",report:""];
     def apiID = uuidfields."$apiType";
     def getURL = baseUrl+props."$apiType"+uuidvals."$apiID"+"/"+subAction+"/"+jobid
     if(subAction == "reports")
         getURL += "?verbose=true"
     def getReq = doRequest(getURL);
     def getRC = getReq.responseCode; 

     def result = parseJson(getReq.responseContent)

     if (getRC.equals(200)) {
       def isDone = result.isComplete;
       if (isDone) {
          reportMap.report = result.verboseReport.join('"').replace('"',System.lineSeparator());
          reportMap.status = "done";
          if(includeSummaryReport)
            reportMap.summaryReport = new groovy.json.JsonBuilder(result["summaryReportJson"]).toString()
       }
       else
          reportMap.status = "waiting";
     }
     else {
       reportMap.status = "failed";
       reportMap.report = "Failed for reason code: " + getRC;
       println(result);
     }
     return(reportMap);
   }

   /**
    * Get the Db2 subsystem information
    * GET /policy/subsystems/db2/<subsysID>
    */
   def getSubsystemInfo() {
      println("## getSubsystemInfo ${uuidvals}")
      def getReq = doRequest(baseUrl + props.subsysAPI + uuidvals.subsysID);
      def getRC = getReq.responseCode;

      def result = parseJson(getReq.responseContent)

      //TODO
      if(getRC.equals(200)) {
         jdbcurl = "jdbc:db2://" + result.url + ":" + result.port + "/" + result.location;
         db2version = result.version;
         db2functionlevel = result.functionLevel;
      }
      else
         println(result);
   }

   /**
    * Check the status of the objects of the current instance
    *
    * @param apiType
    * @param expectedStatus
    */
   String checkStatus(String apiType, String expectedStatus = null) {
      def objID = uuidfields."$apiType";
      def getURL = baseUrl+props."$apiType" + uuidvals."$objID";
      def getReq = doRequest(getURL);
      def getRC = getReq.responseCode;
     
     def result = parseJson(getReq.responseContent)

     if (getRC.equals(200)) {
       if (result.status== "complete" && apiType == "instAPI") {
            schemaNames = result.db2.schemaNames;
            schemaList = result.db2.schemaNames;
            dbNames = result.db2.databaseNames;

            int i = 0;
            int objCount = result.db2Objects.size();
            // uuidvals.subsysID = result.db2Objects[i].subsystem;
            uuidvals.subsysID = result.db2.subsystemIds[0];
            dbMap = result.db2.databaseMap;
            schemaMap = result.db2.schemaMap;
            // get application ID as well for future usage
            uuidvals.appID = result.applicationIds[0];
            while (i < objCount) {
               String fullName = "";
               if (result.db2Objects[i].qualifier == "")
                  fullName = result.db2Objects[i].name;
               else {
                  // get the schema name list as well for future usage
                  if (!(schemaNames.contains(result.db2Objects[i].qualifier)))
                     schemaNames << result.db2Objects[i].qualifier;
                  fullName = result.db2Objects[i].qualifier + '.' + result.db2Objects[i].name;
               } 
               existingDOList << fullName;
               i++;
            }
       }
       return (result.status);
     }
     else if (getRC.equals(404) && expectedStatus == null)
       return ("completed");
     else {
       println(result);
       return ("failed with reason code: " + getRC);
     }
   }

   /**
    * Provision an instance
    * POST /ws/policy/instances
    *
    * @param appName The name of the application
    * @param teamName The team owning the new instance
    * @param envName The environment where the instance is created in
    * @param instName The name for the newly provisioned instance
    */
   String provision(String appName, String teamName, String envName, String instName) {
      logDEBUG("Entering provision with parms appName=${appName}, teamName=${teamName}, envName=${envName}, instName=${instName}")

      println("Provisioning new instance ${instName} of application ${appName} in environment ${envName} for team ${teamName}")

      getUUID("appAPI", appName);
      getUUID("teamAPI", teamName);

      String envID = teamEnvList.get(envName);
      String tID = uuidvals.teamID;
      String aID = uuidvals.appID;

      if(tID == null) {
         def msg = "ERROR: Team ${teamName} not found!"
         println(msg)
         return(msg)
      }
      if(envID == null) {
         def msg = "ERROR: Environment ${envName} not found!"
         println(msg)
         return(msg)
      }
      if(aID == null) {
         def msg = "ERROR: Application ${appName} not found!"
         println(msg)
         return(msg)
      }

      Instance pInst = new Instance(__yamlClass:props.instClass, teamId:tID, 
                                   environmentId:envID, applicationIds:[aID], 
                                   name:instName);
      def pInstJ = new groovy.json.JsonBuilder(pInst);

      def postURL = baseUrl + props.instAPI;
      def postReq = doRequest(postURL, "POST", pInstJ.toString());

      def postRC = postReq.responseCode;

      def result = parseJson(postReq.responseContent);

      def resultS

      if (postRC.equals(201)) {

         uuidvals.instID = result.id;
         resultS = result.status;

         println(resultS)

         if (resultS != "instantiating") {
            println("Provisioning failed with status ${resultS}")
            return ("failed to provision with status: " + resultS)
         }
         
         while (resultS == "instantiating") {
            sleep(5000);
            resultS = checkStatus("instAPI", "complete");
            println("Waiting for the action to complete...")
         }
         
         println("Successfully provisioned instance ${instName} with schema ${schemaNames}");

         //getSubsystemInfo();

         return resultS; 
      }
      else {
        println("Failed to provision instance with error ${result.error}");
        return ("Failed to provision instance with error ${result.error}");
      }
   }

   /**
    * Deprovision an instance
    * DELETE /policy/instances/<instID>
    *
    * @param name The name of the instance to be deleted
    */
   String deprovision(String name) {
      println("Deprovisioning instance ${name}")

      getUUID("instAPI", name)

      def result

      if(uuidvals["instID"] != null) {

         def url = baseUrl + props["instAPI"] + uuidvals["instID"]
         def req = doRequest(url, "DELETE")

         def resp = parseJson(req.responseContent)

         if (req.responseCode == 200) {
            result = checkStatus("instAPI");
            while (result == "deleting") {
               sleep(5000);
               result = checkStatus("instAPI");
               println("Waiting for the action to complete...")
            }
            println("Instance successfully deprovisioned")
         }
         else {
            println("Deprovisioning failed with error ${resp.error}")
         }
      } else {
         println("Instance ${name} not found")
         result = "failed"
      }
      return (result);
   }

   /**
    * Review changes to the objects of an instance
    * POST /policy/instances/{instanceId}/objects/reports
    *
    * @param instName The name of the instance
    * @param appMFName The name of the application JSON manifest
    *
    * @return A Map with report and status
    */
   Map reviewChange(String instName, String appMFName) {
      logDEBUG("Entering reviewChange with parms instName=${instName}, appMFName=${appMFName}")

      println("Analyzing changes for instance ${instName}")

      // get the UUID of the instance
      getUUID("instAPI", instName);

      // check, if instance exists
      if(uuidvals.instID == null) {
         println("Instance ${instName} not found!")
         return [status:"failed", report:"Instance ${instName} not found!"]
      }

      // check the status of the instance
      checkStatus("instAPI", "complete");

      // analyze the application manifest
      mfAnalysis(appMFName);

      def i = 0;
      def dbSet = dbMap.keySet();
      def qk;
      def qv;

      // validate site rules
      def validationErrors = "Analysis failed due to syntax or site rule violations.\n"
      def violations = 0

      for (obj in doList) {
         def objFile = new File(obj.uri)
         def objText = objFile.getText("UTF-8")
         def result = validateDDL(objText, uuidvals.appID)
         if(result.returnCode != 0) {
            violations++
            println("ERROR: Validation failed for object ${obj.type} ${obj.name}")
            for(msg in result.messages) {
               println(msg)
               validationErrors = validationErrors + "${obj.type} ${obj.name}: ${msg}\n" 
            }
         }
         else {
            println("Validation succeeded for object ${obj.type} ${obj.name}")
         }
      }
      if(violations > 0)
         return [status:"failed", report:validationErrors]
      
      def objectsWithError = []
      def rc

      // save objects changes 
      while (i < doList.size()) {

         qk = doList[i].qualifier;

         if (!(['DB','TS'].contains(doList[i].type))) {
            qv = schemaMap["$qk"];
            if (existingDOList.contains(qv + "." + doList[i].name)) {
               rc = saveChange(qv + "." + doList[i].name, doList[i].uri);
            }
            else
               rc = addObject(doList[i].name, doList[i].type, doList[i].qualifier, doList[i].uri);
         }
         else if (doList[i].type == 'TS') {
            qv = dbMap["$qk"];
            if (existingDOList.contains(qv + "." + doList[i].name)) {
               rc = saveChange(qv + "." + doList[i].name, doList[i].uri);
            }
            else
               rc = addObject(doList[i].name, doList[i].type, doList[i].qualifier, doList[i].uri);
         }
         else 
            if (dbSet.contains(doList[i].name))
               rc = saveChange(dbNames[0], doList[i].uri);
            else
               rc = addObject(doList[i].name, doList[i].type, '', doList[i].uri)               

         if(rc != 200) {
            objectsWithError.add(doList[i].type + " " + doList[i].name)
         }
         i++;
      }

      // reset objects if errors occurred
      if(objectsWithError.size() > 0) {
         def url = baseUrl + props["instAPI"] + uuidvals["instID"] + "/objects/restore"
         def req = doRequest(url, "PUT");
         def reqRC = req.responseCode;
         def resultJson = parseJson(req.responseContent);

         if(reqRC == 200) {
            println("Object definitions successfully restored to last commit state")
         }
         else {
            println("Error restoring object definitions")
         }
         //println(resultJson)
         return [status:"failed", report:"One or more errors occurred while saving object definitions. Object definitions restored to last commit state."]
      }

      // get report
      String jobid = requestAction("instAPI", "objects/reports", "jobId");
      def result = getReport("instAPI", "reports", jobid, true);
      //println(result);
      while (result.status == "waiting") {
          sleep(2000);
          result = getReport("instAPI", "reports", jobid, true);
          println("Waiting for action to complete...");
      }
      println("Action completed with status ${result.status.toUpperCase()}");

      return (result);
   }

   /**
    * Applies the changes to an instance
    * POST /policy/instances/{instanceId}/objects/apply
    *
    * @param instName The name of the instance
    */
   Map applyChange(String instName) {
      logDEBUG("Entering applyChange with parms instName=${instName}")
      println("Applying changes to instance ${instName}")
      getUUID("instAPI", instName);

      if(uuidvals.instID == null) {
         println("Instance ${instName} not found!") 
         return [status:"failed", report:"Instance ${instName} not found!"]
      }

      String jobid = requestAction("instAPI", "objects/apply", "jobId");
      def result = getReport("instAPI", "apply", jobid);
      while (result.status == "waiting") {
          sleep(2000);
          result = getReport("instAPI", "apply", jobid);
      }

      // discard changes and restore object definitions when apply fails
      if(result.status == "failed") {
         def url = baseUrl + props["instAPI"] + uuidvals["instID"] + "/objects/discard-apply"
         def req = doRequest(url, "POST");
         def reqRC = req.responseCode;
         def resultJson = parseJson(req.responseContent);

         if(reqRC == 200) {
            println("Apply failed. Discarding changes and restoring object definitions")
         }
         else {
            printl("Apply failed. Error discarding changes")
         }
      }
      else if(result.status == "done") {
         println(result.report);
         println("Changes successfully applied to instance ${instName}")
      }
      logDEBUG("Exiting applyChange")
      return (result);
   }

   /**
    * Promote changes from an instance to the application master
    * POST /policy/pull-requests
    *
    * @param instName
    * @param approver
    * @param approverPwd
    */
   String promoteChange(String instName, String approver, String approverPwd) {
      getUUID("instAPI", instName);
      String prcredential = "$approver:$approverPwd".
                     getBytes("ISO-8859-1").encodeBase64().toString();
      List ruser = [];
      ruser.add(approver.toUpperCase());
      PullRequest pullReq = new PullRequest(__yamlClass:props.pullClass, sourceRepository:"instances",
                                   sourceBranch:uuidvals.instID, targetRepository:"applications",
                                   targetBranch:"master", reviewers:ruser,
                                   sourceInstanceId:uuidvals.instID, title: "Dummy Title");
      def pReqJ = new groovy.json.JsonBuilder(pullReq);
      def postURL = baseUrl + props.pullAPI;
      // TODO
      def postReq = doRequest(postURL, "POST", pReqJ.toString());

      def postRC = postReq.responseCode;
    
      def result = parseJson(postReq.responseContent);

      if (postRC.equals(201)) {
         println("checking the status...")
         uuidvals.pullID = result.id;
         String credentialBackup = credential;
         credential = prcredential;
         String aStatus = requestAction("pullAPI", "approve", "status");
         def pStatus;
         println("approval status: " + aStatus);
         if (aStatus.toUpperCase() == "OPENED") {
            aStatus = requestAction("pullAPI", "merge", "status");
            println("merge status: " + aStatus);
            credential = credentialBackup;
            pStatus = checkStatus("pullAPI");
            while (pStatus == "merging") {
               sleep(5000);
               pStatus = checkStatus("pullAPI");
               println(pStatus);
            }
            println(pStatus);
            if (pStatus.toUpperCase() != "MERGED")
               return("failed to merge the change automatically, require manual merge");
            return (pStatus);
         }
         else
            return("failed to get approval, contact administrator to check");
      }
      else {
         println(result);
         return ("failed to create pull request");
      }
   }

   /**
    * Synchronize changes
    * POST /policy/instances/{instanceId}/objects/pull
    *
    * @param instName 
    */
   Map syncChange(String instName) {
      println("Synchronize instance ${instName} with the master schema")
      getUUID("instAPI", instName);
      println(requestAction("instAPI", "objects/pull", "db2Objects"));
      return (applyChange(instName));
   }

/**
 * A Trust Manager that does not verfiy certificates
 */
   class DefaultTrustManager implements X509TrustManager {
      public java.security.cert.X509Certificate[] getAcceptedIssuers() {
         return null;
      }
      public void checkClientTrusted(
         java.security.cert.X509Certificate[] certs, String authType) {
      }
      public void checkServerTrusted(
         java.security.cert.X509Certificate[] certs, String authType) {
      }
   }
}