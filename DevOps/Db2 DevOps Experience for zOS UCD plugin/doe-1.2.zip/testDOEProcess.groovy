//import classes.com.ibm.db2zos.devops.DOEProcess

import java.util.logging.Logger
import java.util.logging.Level
import java.util.logging.ConsoleHandler
import java.util.logging.Handler

//import groovy.util.logging.Log

class Main {

    private static final log = Logger.getLogger("foo")

    static void main(String... args) {
        def doehost="tivlp02.svl.ibm.com"
        def doeport="12023"
        def instanceName="GENAPP_INTEGRATION"
        def password="DOEPW "
        def printRESTLOG=false
        def untrustedSSL=true
        def userid="DOEDBA1"
        def appDef="app_def.json"

        //def doepObj = new DOEProcess(doehost, doeport, userid, password, untrustedSSL);
        //def aresult = doepObj.reviewChange(instanceName, appDef);

        //Logger log = Logger.getLogger("")

        Handler handler = new ConsoleHandler();
        handler.setLevel( Level.ALL );
        log.addHandler( handler );
        //log.setLevel(Level.parse("ALL"))
        println(log.getLevel())

        println(log.getHandlers())

        log.setUseParentHandlers(false)

        log.info("This is some info")
        log.warning("This is some info")
        foo();
    }

    static void foo() {
        //Logger log = Logger.getLogger("")
        //log.setLevel(Level.parse("ALL"))
        log.finer("Blaaa")
        log.entering("Main", "testDOEProcess")
        log.exiting("foo", "bar")
    }
}